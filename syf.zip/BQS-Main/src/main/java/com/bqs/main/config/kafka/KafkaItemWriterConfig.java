package com.bqs.main.config.kafka;

import com.bqs.main.model.PatientWrapper;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

@Configuration
public class KafkaItemWriterConfig {

    @Value("${spring.kafka.topic}")
    private String topic;

    @Bean
    public ItemWriter<PatientWrapper> patientKafkaWriter(KafkaTemplate<String, PatientWrapper> kafkaTemplate) {
        return items -> {
            for (PatientWrapper wrapper : items) {
                kafkaTemplate.send(topic, wrapper);
            }
        };
    }

    @Bean
    public RetryTemplate retryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();

        // Retry policy → 3 attempts
        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(3); // 2 retries + 1 initial = 3 attempts

        // Backoff policy → 1 second delay between retries
        FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
        backOffPolicy.setBackOffPeriod(1000); // 1000 ms = 1 second

        retryTemplate.setRetryPolicy(retryPolicy);
        retryTemplate.setBackOffPolicy(backOffPolicy);

        return retryTemplate;
    }
}
