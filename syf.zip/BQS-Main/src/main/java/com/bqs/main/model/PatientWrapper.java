package com.bqs.main.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PatientWrapper implements Serializable {

    private Patient patient;
    private FileProcessingLog fileProcessingLog;

    public Patient getPatient() {
        return patient;
    }
    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    public FileProcessingLog getFileProcessingLog() {
        return fileProcessingLog;
    }
    public void setFileProcessingLog(FileProcessingLog fileProcessingLog) {
        this.fileProcessingLog = fileProcessingLog;
    }
}
