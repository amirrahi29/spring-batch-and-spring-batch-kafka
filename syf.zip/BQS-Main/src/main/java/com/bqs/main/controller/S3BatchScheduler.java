package com.bqs.main.controller;

import com.bqs.main.service.S3BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class S3BatchScheduler {

    @Autowired
    private S3BatchService s3BatchService;

    @Value("${scheduler.enabled:false}")
    private boolean schedulerEnabled;

    @Scheduled(cron = "${scheduler.cron}")
    public void triggerBatchFromScheduler() {
        if (schedulerEnabled) {
            System.out.println("==> [Scheduler ENABLED] Triggering batch for all files...");
            s3BatchService.triggerAllFiles();
        } else {
            System.out.println("==> [Scheduler DISABLED] Skipping batch run (flag is false).");
        }
    }
}
