package com.bqs.main.controller;

import com.bqs.main.service.S3BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/s3")
public class S3BatchController {

    @Autowired
    private S3BatchService s3BatchService;

    @GetMapping("/process/{fileKey}")
    public String triggerBatchForFile(@PathVariable String fileKey) {
        try {
            s3BatchService.triggerBatchJob(fileKey);
            return "Job started for file: " + fileKey;
        } catch (Exception e) {
            return "Failed to start job for: " + fileKey + " | Reason: " + e.getMessage();
        }
    }

    @GetMapping("/process-all")
    public ResponseEntity<String> processAllFilesManually() {
        s3BatchService.triggerAllFiles();
        return ResponseEntity.ok("All files submitted for processing.");
    }
}
