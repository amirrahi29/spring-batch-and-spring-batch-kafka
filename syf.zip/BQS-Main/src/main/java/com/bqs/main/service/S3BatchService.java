package com.bqs.main.service;

import com.bqs.main.utility.ChunkSizeDecider;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
public class S3BatchService {

    @Autowired
    private S3Client s3Client;

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private org.springframework.context.ApplicationContext applicationContext;

    @Autowired
    private S3InputStreamFetcher s3InputStreamFetcher;

    @Autowired
    private ChunkSizeDecider chunkSizeDecider;

    @Value("${s3.aws.bucket}")
    private String bucketName;

    // Trigger batch job for a specific file (manual REST call)
    public void triggerBatchJob(String fileKey) {
        try {
            long validRecordCount = s3InputStreamFetcher.countValidRecords(bucketName, fileKey);
            Job patientJob = applicationContext.getBean("patientJob", Job.class);

            int chunkSize = chunkSizeDecider.decide(validRecordCount);

            System.out.println("==> Triggering Batch for file: " + fileKey);
            System.out.println("==> Valid Records: " + validRecordCount);
            System.out.println("==> Chunk Size: " + chunkSize);

            JobParameters params = new JobParametersBuilder()
                    .addString("fileKey", fileKey)
                    .addLong("chunkSize", (long) chunkSize)
                    .addLong("timestamp", System.currentTimeMillis())
                    .toJobParameters();

            jobLauncher.run(patientJob, params);

            System.out.println("Batch job started for file: " + fileKey);

        } catch (Exception e) {
            String rootCause = getRootCauseMessage(e);

            if (rootCause.contains("S3 returned null stream")) {
                System.err.println("==> S3 file not found: " + fileKey + " → skipping.");
            } else {
                System.err.println("Failed to start batch job for file: " + fileKey + " | Reason: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private String getRootCauseMessage(Throwable t) {
        Throwable root = t;
        while (root.getCause() != null && root != root.getCause()) {
            root = root.getCause();
        }
        return root.getMessage();
    }

    // Trigger batch for all files in the S3 bucket (manual REST call)
    public void triggerAllFiles() {
        try {
            ListObjectsV2Request listRequest = ListObjectsV2Request.builder()
                    .bucket(bucketName)
                    .build();

            ListObjectsV2Response listResponse = s3Client.listObjectsV2(listRequest);

            for (S3Object s3Object : listResponse.contents()) {
                String fileKey = s3Object.key();
                System.out.println("==> Submitting batch job for file: " + fileKey);

                // Trigger batch job for each file
                triggerBatchJob(fileKey);
            }

        } catch (Exception e) {
            System.err.println("Failed to process all files | Reason: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
}
