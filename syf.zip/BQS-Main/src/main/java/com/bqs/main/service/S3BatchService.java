package com.bqs.main.service;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
public class S3BatchService {

    @Autowired
    private S3Client s3Client;

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job patientJob; // your Spring Batch job bean

    @Value("${s3.aws.bucket}")
    private String bucketName;

    // This method triggers batch for all files in the S3 bucket
    public void triggerAllFiles() {
        ListObjectsV2Request listRequest = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .build();

        ListObjectsV2Response listResponse = s3Client.listObjectsV2(listRequest);

        for (S3Object s3Object : listResponse.contents()) {
            String key = s3Object.key();
            System.out.println("Processing file: " + key);

            // Trigger batch for each file
            triggerBatchForFile(key);
        }
    }

    // This method triggers batch for a single file
    public boolean triggerBatchForFile(String fileKey) {
        try {
            JobParameters params = new JobParametersBuilder()
                    .addString("fileKey", fileKey)
                    .addLong("timestamp", System.currentTimeMillis()) // To make job instance unique
                    .toJobParameters();

            jobLauncher.run(patientJob, params);

            System.out.println("Batch job started for file: " + fileKey);
            return true;
        } catch (Exception e) {
            System.err.println("Failed to start batch for file: " + fileKey);
            e.printStackTrace();
            return false;
        }
    }
}
