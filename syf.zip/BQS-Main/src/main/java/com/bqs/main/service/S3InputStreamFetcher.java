package com.bqs.main.service;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class S3InputStreamFetcher {

    private final S3Client s3Client;

    public S3InputStreamFetcher(S3Client s3Client) {
        this.s3Client = s3Client;
    }

    public ResponseInputStream<GetObjectResponse> fetch(String bucketName, String fileKey) {
        int retries = 3;

        while (retries > 0) {
            try {
                GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                        .bucket(bucketName)
                        .key(fileKey)
                        .build();

                return s3Client.getObject(getObjectRequest);
            } catch (NoSuchKeyException e) {
                System.err.println("S3 FILE NOT FOUND: " + fileKey + " | " + e.awsErrorDetails().errorMessage());
                return null; // Caller will handle null
            } catch (Exception e) {
                retries--;
                System.err.println("S3 FETCH FAILED: " + fileKey + " | Retries left: " + retries + " | Reason: " + e.getMessage());

                if (retries == 0) {
                    throw new RuntimeException("Failed to fetch S3 object after retries: " + fileKey, e);
                }

                // Backoff before retrying
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {}
            }
        }

        return null; // Should not reach here
    }

    public long countValidRecords(String bucketName, String fileKey) {
        try (InputStream inputStream = fetch(bucketName, fileKey)) {

            if (inputStream == null) {
                throw new RuntimeException("S3 returned null stream for file: " + fileKey + " (probably missing in S3)");
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
            AtomicLong count = new AtomicLong(0);

            String line;
            boolean headerSkipped = false;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.isEmpty()) {
                    continue; // skip empty lines
                }

                // Skip header line
                if (!headerSkipped) {
                    if (line.toLowerCase().contains("correlation id")) {
                        headerSkipped = true;
                    }
                    continue;
                }

                // Skip footer (optional: if footer present)
                if (line.toLowerCase().contains("footer")) {
                    continue;
                }

                // If valid data line → count++
                count.incrementAndGet();
            }

            System.out.println("==> Valid record count for " + fileKey + ": " + count.get());
            return count.get();

        } catch (Exception e) {
            throw new RuntimeException("Failed to count records in file: " + fileKey + " | Reason: " + e.getMessage(), e);
        }
    }
}
