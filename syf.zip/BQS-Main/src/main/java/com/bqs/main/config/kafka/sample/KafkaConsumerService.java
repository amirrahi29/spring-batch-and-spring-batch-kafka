package com.bqs.main.config.kafka.sample;

import com.bqs.main.model.PatientChunk;
import com.bqs.main.model.PatientWrapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {

    private final ObjectMapper objectMapper;

    public KafkaConsumerService() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }

    @KafkaListener(topics = "${spring.kafka.topic}", groupId = "${spring.kafka.consumer.group-id}")
    public void consume(PatientChunk chunk) {
        System.out.println("==> Consumed Chunk of size: " + chunk.getPatients().size());

        for (PatientWrapper wrapper : chunk.getPatients()) {
            try {
                String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(wrapper);
                System.out.println(json);
            } catch (Exception e) {
                System.out.println("Error converting to JSON: " + e.getMessage());
            }
        }
    }
}
