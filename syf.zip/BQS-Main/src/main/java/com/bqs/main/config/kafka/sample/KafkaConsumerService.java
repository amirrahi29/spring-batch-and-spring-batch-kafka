package com.bqs.main.config.kafka.sample;

import com.bqs.main.model.Patient;
import com.bqs.main.model.PatientChunk;
import com.bqs.main.model.PatientWrapper;
import com.bqs.main.utility.AESEncryptionUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicInteger;

@Service
public class KafkaConsumerService {

    private final ObjectMapper objectMapper;
    private final AESEncryptionUtil aesEncryptionUtil;

    private final AtomicInteger totalRecordsCount = new AtomicInteger(0);

    public KafkaConsumerService(AESEncryptionUtil aesEncryptionUtil) {
        this.aesEncryptionUtil = aesEncryptionUtil;
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }

    @KafkaListener(topics = "${spring.kafka.topic}", groupId = "${spring.kafka.consumer.group-id}")
    public void consume(PatientChunk chunk) {

        System.out.println("==> Consumer Chunk: " + chunk);

//        // Each PatientChunk has its own FileProcessingLog — no global counter needed!
//
//        System.out.println("\n=======================================================");
//        System.out.println("==> Consumed Chunk | Records: " + chunk.getPatients().size());
//        System.out.println("=======================================================\n");
//
//        System.out.println("=========================== FileProcessingLog ============================");
//        try {
//            String fileLogJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(chunk.getFileProcessingLog());
//            System.out.println(fileLogJson);
//        } catch (Exception e) {
//            System.out.println("Error converting fileProcessingLog to JSON: " + e.getMessage());
//        }
//
//        chunk.getPatients().forEach(patient -> {
//            try {
//                String decryptedSSN = aesEncryptionUtil.decrypt(patient.getSsn());
//                String decryptedDOB = aesEncryptionUtil.decrypt(patient.getDob());
//                patient.setSsn(decryptedSSN);
//                patient.setDob(decryptedDOB);
//
//                String patientJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(patient);
//                System.out.println(patientJson);
//
//            } catch (Exception e) {
//                System.out.println("Error processing patient: " + e.getMessage());
//            }
//        });

    }
}
