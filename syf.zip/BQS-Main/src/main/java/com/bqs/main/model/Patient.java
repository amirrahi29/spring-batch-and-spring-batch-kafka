package com.bqs.main.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "BQS_PRESCREEN_IN_FILE_INFO")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BQS_PRESCREEN_IN_FILE_INFO_ID")
    private Long id;

    @Column(name = "CORRELATION_ID", nullable = false, length = 25)
    private String correlationId;

    @Column(name = "REFERENCE_ID", nullable = false, length = 25)
    private String refId;

    @Column(name = "OFFER_ID", nullable = false, length = 25)
    private String offerId;

    @Column(name = "FIRST_NAME", nullable = false, length = 25)
    private String firstName;

    @Column(name = "LAST_NAME", nullable = false, length = 25)
    private String lastName;

    @Column(name = "ADDRESS_LINE1", nullable = false, length = 100)
    private String addressLine1;

    @Column(name = "ADDRESS_LINE2", length = 100)
    private String addressLine2;

    @Column(name = "CITY", nullable = false, length = 20)
    private String city;

    @Column(name = "STATE", nullable = false, length = 10)
    private String state;

    @Column(name = "ZIP_CODE", nullable = false, length = 10)
    private String zipCode;

    @Column(name = "EMAIL_ADDRESS", nullable = false, length = 60)
    private String email;

    @Column(name = "PHONENUMBER", nullable = false, length = 20)
    private String phoneNumber;

    @Column(name = "DATEOFBIRTH", length = 64)
    private String dob;

    @Column(name = "SSNITIN", length = 64)
    private String ssn;

    @Column(name = "MERCHANT_ID", nullable = false, length = 16)
    private String merchantId;

    @Column(name = "PARTNER_CODE", length = 40)
    private String partnerCode;

    @Column(name = "PRODUCT_CODE", length = 5)
    private String productCode;

    @Column(name = "GROUP_CODE", length = 5)
    private String groupCode;

    @Column(name = "CLIENT_ID", length = 20)
    private String clientId;

    @Column(name = "INDUSTRY_ID", length = 10)
    private String industryId;

    @Column(name = "PROCESS_STATUS", length = 30)
    private String processStatus;

    @Column(name = "STATUS", length = 30)
    private String status; // ex: UNPROCESSED, PROCESSED, FAILED

    @Column(name = "MESSAGE", length = 1000)
    private String message;

    @Column(name = "ACCOUNT_VERIFICATION")
    private Boolean accountVerification;

    @Column(name = "AVAILABLE_CREDIT", length = 10)
    private String availableCredit;

    @Column(name = "AUTH_NBR")
    private Long authNumber;

    @Column(name = "PREAPPROVAL_AMT", precision = 8, scale = 2)
    private java.math.BigDecimal preapprovalAmount;

    @Column(name = "PURL", length = 200)
    private String purl;

    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "UPDATED_DATE")
    private LocalDateTime updatedDate;

    @Column(name = "BQS_PRESCREEN_FILE_INFO_ID")
    private Long fileInfoId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getPartnerCode() {
        return partnerCode;
    }

    public void setPartnerCode(String partnerCode) {
        this.partnerCode = partnerCode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getIndustryId() {
        return industryId;
    }

    public void setIndustryId(String industryId) {
        this.industryId = industryId;
    }

    public String getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(String processStatus) {
        this.processStatus = processStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getAccountVerification() {
        return accountVerification;
    }

    public void setAccountVerification(Boolean accountVerification) {
        this.accountVerification = accountVerification;
    }

    public String getAvailableCredit() {
        return availableCredit;
    }

    public void setAvailableCredit(String availableCredit) {
        this.availableCredit = availableCredit;
    }

    public Long getAuthNumber() {
        return authNumber;
    }

    public void setAuthNumber(Long authNumber) {
        this.authNumber = authNumber;
    }

    public BigDecimal getPreapprovalAmount() {
        return preapprovalAmount;
    }

    public void setPreapprovalAmount(BigDecimal preapprovalAmount) {
        this.preapprovalAmount = preapprovalAmount;
    }

    public String getPurl() {
        return purl;
    }

    public void setPurl(String purl) {
        this.purl = purl;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getFileInfoId() {
        return fileInfoId;
    }

    public void setFileInfoId(Long fileInfoId) {
        this.fileInfoId = fileInfoId;
    }

}
