package com.bqs.main.utility;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Component
public class AESEncryptionUtil {

    @Value("${AES.secretKey}")
    private String secretKey;

    @Value("${AES.transformation}")
    private String transformation;

    @Value("${AES.name}")
    private String name;

    public String encrypt(String strToEncrypt) {
        try {
            if (strToEncrypt == null || strToEncrypt.isEmpty()) {
                return strToEncrypt;
            }
            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes("UTF-8"), name);
            Cipher cipher = Cipher.getInstance(transformation);
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            byte[] encryptedBytes = cipher.doFinal(strToEncrypt.getBytes("UTF-8"));
            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception e) {
            System.out.println("Error while encrypting: " + e.getMessage());
            return null;
        }
    }

    public String decrypt(String strToDecrypt) {
        try {
            if (strToDecrypt == null || strToDecrypt.isEmpty()) {
                return strToDecrypt;
            }
            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes("UTF-8"), name);
            Cipher cipher = Cipher.getInstance(transformation);
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(strToDecrypt));
            return new String(decryptedBytes, "UTF-8");
        } catch (Exception e) {
            System.out.println("Error while decrypting: " + e.getMessage());
            return null;
        }
    }
}
