package com.bqs.main.batch.reader;

import com.bqs.main.model.Patient;
import com.bqs.main.service.S3InputStreamFetcher;
import org.apache.commons.io.IOUtils;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import static com.bqs.main.utility.FileHeaderConstants.*;

@Component
public class S3BatchReader {

    @Autowired
    private S3InputStreamFetcher s3InputStreamFetcher;

    @Value("${s3.aws.bucket}")
    private String bucketName;

    private List<String> skippedRecords = new CopyOnWriteArrayList<>();

    @StepScope
    public FlatFileItemReader<Patient> s3FlatFileItemReader(@Value("#{jobParameters['fileKey']}") String fileKey) {
        try {
            if (!fileKey.toLowerCase().endsWith(".txt")) {
                throw new RuntimeException("Invalid file type: " + fileKey + " | Only .txt files are supported.");
            }

            System.out.println("==> Fetching file from S3: " + fileKey);

            InputStream originalStream = s3InputStreamFetcher.fetch(bucketName, fileKey);
            if (originalStream == null) {
                throw new RuntimeException("S3 file not found: " + fileKey + " (fetch returned null)");
            }

            byte[] fileBytes = IOUtils.toByteArray(originalStream);
            ByteArrayInputStream headerStream = new ByteArrayInputStream(fileBytes);
            ByteArrayInputStream dataStream = new ByteArrayInputStream(fileBytes);

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(headerStream, StandardCharsets.UTF_8));
            String headerLine;
            do {
                headerLine = bufferedReader.readLine();
            } while (headerLine != null && !headerLine.toLowerCase().contains("correlation id"));

            if (headerLine == null) {
                throw new RuntimeException("Header line not found in file: " + fileKey);
            }

            // Build header index map
            List<String> headers = Arrays.asList(headerLine.split(","));
            Map<String, Integer> headerIndexMap = new LinkedHashMap<>();

            // List to store actual column names for tokenizer
            List<String> actualHeaderNames = new ArrayList<>();

            for (int i = 0; i < headers.size(); i++) {
                String normalized = headers.get(i).trim();

                if (i == 0 && normalized.equalsIgnoreCase("Header")) {
                    System.out.println("==> Skipping dummy 'Header' column at index 0");
                    continue;
                }

                headerIndexMap.put(normalized, i);
                actualHeaderNames.add(normalized);
            }

            // Tokenizer
            DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
            tokenizer.setDelimiter(",");
            tokenizer.setStrict(false);
            tokenizer.setQuoteCharacter('"');  // Safe for future

            // Final fix → set column names from actual header (without "Header" column)
            tokenizer.setNames(actualHeaderNames.toArray(new String[0]));

            // Line mapper
            DefaultLineMapper<Patient> lineMapper = new DefaultLineMapper<>();
            lineMapper.setLineTokenizer(tokenizer);
            lineMapper.setFieldSetMapper(new FieldSetMapper<>() {
                @Override
                public Patient mapFieldSet(FieldSet fs) {
                    try {
                        String firstField = fs.readString(0);
                        if (firstField != null && firstField.toLowerCase().contains("footer")) {
                            skippedRecords.add("Skipped footer line");
                            return null;
                        }

                        Patient p = new Patient();

                        // Map each field → NOW using field name → 100% safe
                        for (String key : actualHeaderNames) {
                            String value = fs.readString(key);
                            value = (value != null && !value.trim().equalsIgnoreCase("null")) ? value.trim() : "";

                            switch (key) {
                                case CORRELATION_ID:
                                    p.setCorrelationId(value);
                                    break;
                                case FIRST_NAME:
                                    p.setFirstName(value);
                                    break;
                                case LAST_NAME:
                                    p.setLastName(value);
                                    break;
                                case ADDRESS_LINE_1:
                                    p.setAddressLine1(value);
                                    break;
                                case ADDRESS_LINE_2:
                                    p.setAddressLine2(value);
                                    break;
                                case CITY:
                                    p.setCity(value);
                                    break;
                                case STATE:
                                    p.setState(value);
                                    break;
                                case ZIP_CODE:
                                    p.setZipCode(value);
                                    break;
                                case EMAIL_ADDRESS:
                                    p.setEmail(value);
                                    break;
                                case MERCHANT_NUMBER:
                                    p.setMerchantId(value);
                                    break;
                                case SSN:
                                    p.setSsn(value);
                                    break;
                                case DATE_OF_BIRTH:
                                    p.setDob(value);
                                    break;
                                case PHONE_NUMBER:
                                    p.setPhoneNumber(value);
                                    break;
                                default:
                                    break;
                            }
                        }

                        // Business logic
                        p.setRefId(p.getCorrelationId());

                        return p;

                    } catch (Exception e) {
                        skippedRecords.add("Skipped line due to parse error: " + e.getMessage());
                        return null;
                    }
                }
            });

            // Build reader
            FlatFileItemReader<Patient> reader = new FlatFileItemReaderBuilder<Patient>()
                    .name("s3FlatFileItemReaderCustom")
                    .resource(new InputStreamResource(dataStream))
                    .linesToSkip(1)
                    .lineMapper(lineMapper)
                    .build();

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (!skippedRecords.isEmpty()) {
                    System.out.println("===== Skipped Records Summary =====");
                    skippedRecords.forEach(System.out::println);
                }
            }));

            return reader;

        } catch (IOException ioe) {
            throw new RuntimeException("IO error while reading file: " + fileKey + " | Reason: " + ioe.getMessage(), ioe);
        } catch (Exception e) {
            throw new RuntimeException("Failed to read file from S3: " + fileKey + " | Reason: " + e.getMessage(), e);
        }
    }
}
