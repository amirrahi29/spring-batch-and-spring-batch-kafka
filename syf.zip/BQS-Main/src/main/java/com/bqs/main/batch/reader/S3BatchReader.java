package com.bqs.main.batch.reader;

import com.bqs.main.model.Patient;
import com.bqs.main.service.S3InputStreamFetcher;
import org.apache.commons.io.IOUtils;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.InputStreamResource;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.*;

@Configuration
public class S3BatchReader {

    @Autowired
    private S3InputStreamFetcher s3InputStreamFetcher;

    @Value("${s3.aws.bucket}")
    private String bucketName;

    @Bean(name = "s3FlatFileItemReaderCustom")
    @StepScope
    public FlatFileItemReader<Patient> s3FlatFileItemReader(@Value("#{jobParameters['fileKey']}") String fileKey) {
        try {
            InputStream originalStream = s3InputStreamFetcher.fetch(bucketName, fileKey);
            byte[] fileBytes = IOUtils.toByteArray(originalStream);

            // Use two streams: one to read header, one for data
            ByteArrayInputStream headerStream = new ByteArrayInputStream(fileBytes);
            ByteArrayInputStream dataStream = new ByteArrayInputStream(fileBytes);

            // Read header line
            BufferedReader reader = new BufferedReader(new InputStreamReader(headerStream, StandardCharsets.UTF_8));
            String headerLine;
            do {
                headerLine = reader.readLine();
            } while (headerLine != null && !headerLine.toLowerCase().contains("correlation id"));

            if (headerLine == null) {
                throw new RuntimeException("Header line not found");
            }

            // Normalize headers
            List<String> rawHeaders = new ArrayList<>(Arrays.asList(headerLine.split(",")));
            if (!rawHeaders.isEmpty() && rawHeaders.get(0).trim().equalsIgnoreCase("header")) {
                rawHeaders.remove(0);
            }

            Map<String, Integer> normalizedHeaderIndexMap = new HashMap<>();
            for (int i = 0; i < rawHeaders.size(); i++) {
                String normalizedKey = normalizeHeader(rawHeaders.get(i));
                normalizedHeaderIndexMap.put(normalizedKey, i);
            }

            // Configure tokenizer
            DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
            tokenizer.setDelimiter(",");
            tokenizer.setStrict(false);
            tokenizer.setQuoteCharacter('"');
            tokenizer.setIncludedFields(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13); // force 14 columns

            // Line mapper
            DefaultLineMapper<Patient> lineMapper = new DefaultLineMapper<>();
            lineMapper.setLineTokenizer(tokenizer);
            lineMapper.setFieldSetMapper(new FieldSetMapper<>() {
                @Override
                public Patient mapFieldSet(FieldSet fs) {
                    try {
                        String firstField = fs.readString(0);
                        if (firstField != null && firstField.toLowerCase().contains("footer")) {
                            return null;
                        }

                        Patient p = new Patient();
                        p.setCorrelationId(get(fs, normalizedHeaderIndexMap, "correlation_id", UUID()));
                        p.setFirstName(get(fs, normalizedHeaderIndexMap, "first_name", "NA"));
                        p.setLastName(get(fs, normalizedHeaderIndexMap, "last_name", "NA"));
                        p.setAddressLine1(get(fs, normalizedHeaderIndexMap, "address_line_1", "NA"));
                        p.setAddressLine2(get(fs, normalizedHeaderIndexMap, "address_line_2", "NA"));
                        p.setCity(get(fs, normalizedHeaderIndexMap, "city", "NA"));
                        p.setState(get(fs, normalizedHeaderIndexMap, "state", "XX"));
                        p.setZipCode(get(fs, normalizedHeaderIndexMap, "zip_code", "00000"));
                        p.setEmail(get(fs, normalizedHeaderIndexMap, "email_address", "default@example.com"));
                        p.setPhoneNumber(get(fs, normalizedHeaderIndexMap, "phone_number", "0000000000"));
                        p.setDob(get(fs, normalizedHeaderIndexMap, "date_of_birth", "1970-01-01"));
                        p.setSsn(get(fs, normalizedHeaderIndexMap, "ssn", "000-00-0000"));
                        p.setMerchantId(get(fs, normalizedHeaderIndexMap, "merchant_number", "000000"));

                        p.setRefId(get(fs, normalizedHeaderIndexMap, "reference_id", p.getCorrelationId()));
                        p.setOfferId(get(fs, normalizedHeaderIndexMap, "offer_id", p.getCorrelationId()));

                        p.setPartnerCode("PARTNER01");
                        p.setProductCode("PRD1");
                        p.setGroupCode("GRP1");
                        p.setClientId("CLIENT001");
                        p.setIndustryId("INDUSTRY1");
                        p.setProcessStatus("COMPLETED");
                        p.setStatus("PROCESSED");
                        p.setMessage("Auto-filled record.");
                        p.setAvailableCredit("1000");
                        p.setAuthNumber(9999999999L);
                        p.setPreapprovalAmount(new BigDecimal("10000.00"));
                        p.setPurl("https://example.com");
                        p.setCreatedDate(LocalDateTime.now());
                        p.setUpdatedDate(LocalDateTime.now());
                        p.setFileInfoId(0L);
                        p.setAccountVerification(false);

                        return p;
                    } catch (Exception e) {
                        return null;
                    }
                }

                private String get(FieldSet fs, Map<String, Integer> map, String key, String fallback) {
                    Integer idx = map.get(key);
                    try {
                        if (idx != null && idx < fs.getFieldCount()) {
                            String s = fs.readString(idx);
                            return (s != null && !s.trim().equalsIgnoreCase("null") && !s.trim().isEmpty()) ? s.trim() : fallback;
                        }
                    } catch (Exception e) {
                        return fallback;
                    }
                    return fallback;
                }

                private String UUID() {
                    return UUID.randomUUID().toString().replace("-", "").substring(0, 25);
                }
            });

            // Build reader
            return new FlatFileItemReaderBuilder<Patient>()
                    .name("s3FlatFileItemReaderCustom")
                    .resource(new InputStreamResource(dataStream))
                    .linesToSkip(1)
                    .lineMapper(lineMapper)
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Failed to read file from S3: " + fileKey, e);
        }
    }

    private String normalizeHeader(String header) {
        return header.trim().toLowerCase().replaceAll("[^a-z0-9]", "_");
    }
}
