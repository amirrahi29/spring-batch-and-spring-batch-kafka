package com.bqs.main.utility;

import org.springframework.stereotype.Component;

@Component
public class ChunkSizeDecider {
    public int decide(long recordCount) {
        if (recordCount <= 1_000) {
            return 100;
        } else if (recordCount <= 10_000) {
            return 200;
        } else if (recordCount <= 100_000) {
            return 200;
        } else if (recordCount <= 1_000_000) {
            return 200;
        } else {
            return 200;
        }
    }
}
