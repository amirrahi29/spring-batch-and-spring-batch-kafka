package com.bqs.main.config.kafka.sample;

import com.bqs.main.model.FileProcessingLog;
import com.bqs.main.model.Patient;
import com.bqs.main.model.PatientWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class KafkaProducerController {

    @Autowired
    private KafkaTemplate<String, PatientWrapper> kafkaTemplate;

    @Value("${spring.kafka.topic}")
    private String topic;

    @GetMapping("/publish")
    public String sendMessage() {

        //patient table
        Patient patient = new Patient();
        patient.setRefId("3525245827523857");
        patient.setEmail("amir@gmail.com");

        //file info table
        FileProcessingLog fileProcessingLog = new FileProcessingLog();
        fileProcessingLog.setFileName("file1.txt");
        fileProcessingLog.setFileName("150MB");

        //main table
        PatientWrapper patientWrapper = new PatientWrapper();
        patientWrapper.setPatient(patient);
        patientWrapper.setFileProcessingLog(fileProcessingLog);

        kafkaTemplate.send(topic, patientWrapper);
        return "Message published to Kafka topic: " + topic;
    }
}
