package com.bqs.main.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "BQS_PRESCREEN_FILE_INFO")
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileProcessingLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BQS_PRESCREEN_FILE_INFO_ID")
    private Long id;

    @Column(name = "FILE_NAME", nullable = false, length = 200)
    private String fileName;

    @Column(name = "FILE_TYPE", nullable = false, length = 3)
    private String fileType;

    @Column(name = "FILE_SIZE", nullable = false, length = 10)
    private String fileSize;

    @Column(name = "PROCESS_START_TIME")
    private LocalDateTime processStartTime;

    @Column(name = "PROCESS_END_TIME")
    private LocalDateTime processEndTime;

    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "UPDATED_DATE")
    private LocalDateTime updatedDate;

    public FileProcessingLog(){}

    public FileProcessingLog(String fileName, String fileType, String fileSize, LocalDateTime processStartTime,
                             LocalDateTime processEndTime, LocalDateTime createdDate, LocalDateTime updatedDate) {
        this.fileName = fileName;
        this.fileType = fileType;
        this.fileSize = fileSize;
        this.processStartTime = processStartTime;
        this.processEndTime = processEndTime;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public LocalDateTime getProcessStartTime() {
        return processStartTime;
    }

    public void setProcessStartTime(LocalDateTime processStartTime) {
        this.processStartTime = processStartTime;
    }

    public LocalDateTime getProcessEndTime() {
        return processEndTime;
    }

    public void setProcessEndTime(LocalDateTime processEndTime) {
        this.processEndTime = processEndTime;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }
}
