package com.bqs.main.config.kafka;

import com.bqs.main.model.FileProcessingLog;
import com.bqs.main.model.PatientChunk;
import com.bqs.main.model.PatientWrapper;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.Chunk;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Scope;

import java.util.ArrayList;
import java.util.List;

@Component
@Scope("step")  // STEP-SCOPED!
public class KafkaPatientWriter implements ItemWriter<PatientWrapper> {

    @Value("${spring.kafka.topic}")
    private String topic;

    private final List<PatientWrapper> buffer = new ArrayList<>();
    private FileProcessingLog fileProcessingLog = null;

    private int batchSize;
    private int chunkCounter = 0;

    private final KafkaTemplate<String, PatientChunk> kafkaTemplate;
    private final RetryTemplate retryTemplate;

    public KafkaPatientWriter(KafkaTemplate<String, PatientChunk> kafkaTemplate,
                              RetryTemplate retryTemplate) {
        this.kafkaTemplate = kafkaTemplate;
        this.retryTemplate = retryTemplate;
    }

    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {
        Long chunkSizeParam = stepExecution.getJobParameters().getLong("chunkSize");
        this.batchSize = chunkSizeParam.intValue();
        this.chunkCounter = 0;

        System.out.println("===> KafkaPatientWriter dynamic batch size set to: " + this.batchSize);
    }

    @Override
    public synchronized void write(Chunk<? extends PatientWrapper> chunk) throws Exception {
        for (PatientWrapper patientWrapper : chunk) {
            // Set FileProcessingLog only once (from first PatientWrapper)
            if (fileProcessingLog == null && patientWrapper.getFileProcessingLog() != null) {
                fileProcessingLog = patientWrapper.getFileProcessingLog();
            }

            buffer.add(patientWrapper);

            // Flush if buffer is full
            if (buffer.size() >= batchSize) {
                flushBuffer();
            }
        }
    }

    // Optional background safety flush (still useful for big batches)
    @Scheduled(fixedDelay = 60000)
    public void scheduledFlush() {
        flushBuffer();
    }

    public synchronized void flushBuffer() {
        if (!buffer.isEmpty() && fileProcessingLog != null) {
            chunkCounter++;

            retryTemplate.execute(context -> {
                System.out.println("==> Produced Kafka Chunk #" + chunkCounter + " | Records: " + buffer.size());

                PatientChunk patientChunk = new PatientChunk();
                patientChunk.setPatients(new ArrayList<>(buffer.stream().map(PatientWrapper::getPatient).toList()));

                // FIX: Deep copy of FileProcessingLog (copy ALL FIELDS)
                FileProcessingLog logCopy = new FileProcessingLog();
                logCopy.setFileName(fileProcessingLog.getFileName());
                logCopy.setFileSize(fileProcessingLog.getFileSize());
                logCopy.setFileType(fileProcessingLog.getFileType());
                logCopy.setProcessStartTime(fileProcessingLog.getProcessStartTime());
                logCopy.setProcessEndTime(fileProcessingLog.getProcessEndTime());
                logCopy.setCreatedDate(fileProcessingLog.getCreatedDate());
                logCopy.setUpdatedDate(fileProcessingLog.getUpdatedDate());

                patientChunk.setFileProcessingLog(logCopy);

                try {
                    kafkaTemplate.send(topic, patientChunk).get();

                    System.out.println("Successfully sent chunk of size: " + patientChunk.getPatients().size());
                    buffer.clear();
                    // NOTE: Do not clear fileProcessingLog here → it will be reused for last flush if needed
                } catch (Exception e) {
                    System.err.println("Failed to send chunk: " + e.getMessage());
                    throw new RuntimeException("Kafka send failed", e);
                }

                return null;
            });
        } else if (!buffer.isEmpty()) {
            System.err.println("==> WARNING: Buffer not flushed because FileProcessingLog is NULL!");
        }
    }

    // Setter — optional external injection if needed
    public void setFileProcessingLog(FileProcessingLog fileProcessingLog) {
        this.fileProcessingLog = fileProcessingLog;
    }
}
