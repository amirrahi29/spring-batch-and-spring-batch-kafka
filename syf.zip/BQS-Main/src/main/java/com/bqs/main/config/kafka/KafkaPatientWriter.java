package com.bqs.main.config.kafka;

import com.bqs.main.model.PatientChunk;
import com.bqs.main.model.PatientWrapper;
import org.springframework.batch.item.Chunk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class KafkaPatientWriter implements org.springframework.batch.item.ItemWriter<PatientWrapper> {

    @Value("${spring.kafka.topic}")
    private String topic;

    private final List<PatientWrapper> buffer = new ArrayList<>();
    private static final int BATCH_SIZE = 500;

    @Autowired
    private KafkaTemplate<String, PatientChunk> kafkaTemplate;

    @Autowired
    private RetryTemplate retryTemplate;

    @Override
    public synchronized void write(Chunk<? extends PatientWrapper> chunk) throws Exception {
        for (PatientWrapper patientWrapper : chunk) {
            buffer.add(patientWrapper);
            if (buffer.size() >= BATCH_SIZE) {
                flushBuffer();
            }
        }
    }

    @Scheduled(fixedDelay = 60000)
    public void scheduledFlush() {
        flushBuffer();
    }

    private synchronized void flushBuffer() {
        if (!buffer.isEmpty()) {
            retryTemplate.execute(context -> {
                System.out.println("Produced chunk of size: " + buffer.size());

                // Prepare PatientChunk
                PatientChunk chunk = new PatientChunk();
                chunk.setPatients(new ArrayList<>(buffer));

                // Send PatientChunk
                kafkaTemplate.send(topic, chunk);

                // Clear buffer
                buffer.clear();

                return null;
            });
        }
    }
}
