package com.bqs.main.batch.listener;

import com.bqs.main.service.S3InputStreamFetcher;
import com.bqs.main.utility.BaseLogger;
import com.bqs.main.utility.FileSizeFormatter;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;

@Component
public class S3JobExecutionListener extends BaseLogger implements JobExecutionListener {

    @Autowired
    private S3InputStreamFetcher s3Fetcher;

    @Autowired
    private S3Client s3Client;

    @Value("${s3.aws.bucket}")
    private String bucketName;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String fileKey = jobExecution.getJobParameters().getString("fileKey");

        if (fileKey == null || fileKey.isBlank()) {
            log.error("No fileKey provided to beforeJob! Failing Job.");
            throw new RuntimeException("Missing required fileKey parameter.");
        }

        try {
            // Fetch full metadata (HeadObjectResponse)
            HeadObjectRequest headObjectRequest = HeadObjectRequest.builder()
                    .bucket(bucketName)
                    .key(fileKey)
                    .build();

            HeadObjectResponse headObjectResponse = s3Client.headObject(headObjectRequest);

            long fileSizeInBytes = headObjectResponse.contentLength();
            String fileType = headObjectResponse.contentType();
            String fileName = fileKey;

            String formattedFileSize = FileSizeFormatter.formatFileSize(fileSizeInBytes);

            log.info("S3 file found. Metadata -> Name: {}, Size: {} ({}) , Type: {}", fileName, fileSizeInBytes, formattedFileSize, fileType);

            // Put in ExecutionContext for use in Writer
            jobExecution.getExecutionContext().put("fileSize", formattedFileSize);
            jobExecution.getExecutionContext().put("fileType", fileType);
            jobExecution.getExecutionContext().put("fileName", fileName);

        } catch (S3Exception e) {
            if (e.statusCode() == 404) {
                throw new RuntimeException("S3 file does not exist: " + fileKey);
            } else {
                throw new RuntimeException("Error checking S3 file metadata: " + e.awsErrorDetails().errorMessage());
            }
        }
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        String fileKey = jobExecution.getJobParameters().getString("fileKey");

        if (fileKey == null || fileKey.isBlank()) {
            log.warn("No fileKey provided. Skipping S3 deletion.");
            return;
        }

        if (jobExecution.getStatus() != BatchStatus.COMPLETED) {
            log.warn("Job did not complete successfully for file: {}. Skipping S3 deletion.", fileKey);
            return;
        }

        // Check how many records were actually read
        int totalReadCount = jobExecution.getStepExecutions()
                .stream()
                .mapToInt(stepExec -> Math.toIntExact(stepExec.getReadCount()))
                .sum();

        if (totalReadCount == 0) {
            log.warn("Job completed but no records were read from file: {}. Skipping S3 deletion.", fileKey);
            return;
        }

        try {
            // Attempt deletion
            DeleteObjectRequest deleteRequest = DeleteObjectRequest.builder()
                    .bucket(bucketName)
                    .key(fileKey)
                    .build();

            s3Client.deleteObject(deleteRequest);

            log.info("S3 file deleted after successful Batch with {} records read: {}", totalReadCount, fileKey);

        } catch (S3Exception e) {
            if (e.statusCode() == 404) {
                log.warn("S3 file was already deleted or not found: {}", fileKey);
            } else {
                log.error("Error deleting S3 file: {} | Reason: {}", fileKey, e.awsErrorDetails().errorMessage());
            }
        } catch (Exception e) {
            log.error("Unexpected error while deleting S3 file: {} | Exception: {}", fileKey, e.getMessage(), e);
        }
    }
}
