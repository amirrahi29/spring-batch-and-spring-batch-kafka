package com.bqs.main.batch.listener;

import com.bqs.main.service.S3InputStreamFetcher;
import com.bqs.main.utility.BaseLogger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;

@Component
public class S3JobExecutionListener extends BaseLogger implements JobExecutionListener {

    @Autowired
    private S3InputStreamFetcher s3Fetcher;

    @Autowired
    private S3Client safeKey;

    @Value("${s3.aws.bucket}")
    private String bucketName;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String fileKey = jobExecution.getJobParameters().getString("fileKey");

        try {
            HeadObjectRequest headObjectRequest = HeadObjectRequest.builder()
                    .bucket(bucketName)
                    .key(fileKey)
                    .build();

            safeKey.headObject(headObjectRequest);
        } catch (S3Exception e) {
            if (e.statusCode() == 404) {
                throw new RuntimeException("S3 file does not exist: " + fileKey);
            } else {
                throw new RuntimeException("Error checking S3 file existence: " + e.awsErrorDetails().errorMessage());
            }
        }
    }


    @Override
    public void afterJob(JobExecution jobExecution) {
        String fileKey = jobExecution.getJobParameters().getString("fileKey");

        if (fileKey == null || fileKey.isBlank()) {
            log.warn("No fileKey provided. Skipping deletion.");
            return;
        }

        if (jobExecution.getStatus().isUnsuccessful()) {
            log.warn("Job failed for file: {}. Skipping S3 deletion.", fileKey);
            return;
        }

    }
}
