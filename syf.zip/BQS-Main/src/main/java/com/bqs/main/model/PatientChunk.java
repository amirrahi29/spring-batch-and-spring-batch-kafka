package com.bqs.main.model;

import java.util.List;

public class PatientChunk {

    private FileProcessingLog fileProcessingLog;
    private List<Patient> patients;

    public FileProcessingLog getFileProcessingLog() {
        return fileProcessingLog;
    }

    public void setFileProcessingLog(FileProcessingLog fileProcessingLog) {
        this.fileProcessingLog = fileProcessingLog;
    }

    public List<Patient> getPatients() {
        return patients;
    }

    public void setPatients(List<Patient> patients) {
        this.patients = patients;
    }

    @Override
    public String toString() {
        return "PatientChunk{" +
                "fileProcessingLog=" + fileProcessingLog +
                ", patients=" + patients +
                '}';
    }
}
