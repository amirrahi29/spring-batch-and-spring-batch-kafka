package com.bqs.main.model;

import java.util.List;

public class PatientChunk {

    private List<PatientWrapper> patients;

    public List<PatientWrapper> getPatients() {
        return patients;
    }

    public void setPatients(List<PatientWrapper> patients) {
        this.patients = patients;
    }
}

