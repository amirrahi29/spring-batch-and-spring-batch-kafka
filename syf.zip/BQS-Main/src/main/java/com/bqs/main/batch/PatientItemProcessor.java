package com.bqs.main.batch;

import com.bqs.main.model.Patient;
import com.bqs.main.model.PatientWrapper;
import com.bqs.main.model.FileProcessingLog;
import com.bqs.main.utility.AESEncryptionUtil;
import org.springframework.batch.item.ItemProcessor;

public class PatientItemProcessor implements ItemProcessor<Patient, PatientWrapper> {

    private final FileProcessingLog fileProcessingLog;
    private final AESEncryptionUtil aesEncryptionUtil;

    public PatientItemProcessor(FileProcessingLog fileProcessingLog, AESEncryptionUtil aesEncryptionUtil) {
        this.fileProcessingLog = fileProcessingLog;
        this.aesEncryptionUtil = aesEncryptionUtil;
    }

    @Override
    public PatientWrapper process(Patient patient) throws Exception {

        // Encrypt SSN
        String encryptedSSN = aesEncryptionUtil.encrypt(patient.getSsn());
        patient.setSsn(encryptedSSN);

        // Encrypt DOB
        String encryptedDOB = aesEncryptionUtil.encrypt(patient.getDob());
        patient.setDob(encryptedDOB);

        // Wrap into PatientWrapper
        PatientWrapper wrapper = new PatientWrapper();
        wrapper.setPatient(patient);
        wrapper.setFileProcessingLog(fileProcessingLog);

        return wrapper;
    }
}
