package com.bqs.main.batch;

import com.bqs.main.batch.listener.S3JobExecutionListener;
import com.bqs.main.batch.reader.S3BatchReader;
import com.bqs.main.config.kafka.KafkaPatientWriter;
import com.bqs.main.model.FileProcessingLog;
import com.bqs.main.model.Patient;
import com.bqs.main.model.PatientWrapper;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import java.time.LocalDateTime;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final S3BatchReader s3BatchReader;
    private final S3JobExecutionListener s3JobExecutionListener;
    private final KafkaPatientWriter kafkaPatientWriter;

    @Autowired
    public BatchConfig(JobRepository jobRepository,
                       PlatformTransactionManager transactionManager,
                       S3BatchReader s3BatchReader,
                       S3JobExecutionListener s3JobExecutionListener,
                       KafkaPatientWriter kafkaPatientWriter) {
        this.jobRepository = jobRepository;
        this.transactionManager = transactionManager;
        this.s3BatchReader = s3BatchReader;
        this.s3JobExecutionListener = s3JobExecutionListener;
        this.kafkaPatientWriter = kafkaPatientWriter;
    }

    @Bean(name = "s3FlatFileItemReader")
    @StepScope
    public FlatFileItemReader<Patient> s3FlatFileItemReader(@Value("#{jobParameters['fileKey']}") String fileKey) {
        return s3BatchReader.s3FlatFileItemReader(fileKey);
    }

    @Bean
    public Step patientStep(FlatFileItemReader<Patient> s3FlatFileItemReader) {
        return new StepBuilder("patientStep", jobRepository)
                .<Patient, PatientWrapper>chunk(5000, transactionManager)
                .reader(s3FlatFileItemReader)
                .processor(patientProcessor())
                .writer(kafkaPatientWriter)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(Integer.MAX_VALUE)
                .taskExecutor(taskExecutor())
                .build();
    }

    @Bean
    public ItemProcessor<Patient, PatientWrapper> patientProcessor() {
        return patient -> {
            PatientWrapper wrapper = new PatientWrapper();
            wrapper.setPatient(patient);

            FileProcessingLog fileProcessingLog = new FileProcessingLog();
            fileProcessingLog.setFileName("patient_" + patient.getCorrelationId() + ".txt");
            fileProcessingLog.setFileType("TXT");
            fileProcessingLog.setFileSize("100KB");
            fileProcessingLog.setProcessStartTime(LocalDateTime.now());
            fileProcessingLog.setProcessEndTime(LocalDateTime.now());
            fileProcessingLog.setCreatedDate(LocalDateTime.now());
            fileProcessingLog.setUpdatedDate(LocalDateTime.now());

            wrapper.setFileProcessingLog(fileProcessingLog);

            return wrapper;
        };
    }

    @Bean
    public Job patientJob(Step patientStep) {
        return new JobBuilder("patientJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(patientStep)
                .listener(s3JobExecutionListener)
                .build();
    }

    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(200);
        executor.setThreadNamePrefix("batch-thread-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.initialize();
        return executor;
    }
}
