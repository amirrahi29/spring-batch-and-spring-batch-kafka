package com.bqs.main.batch;

import com.bqs.main.batch.listener.S3JobExecutionListener;
import com.bqs.main.batch.reader.S3BatchReader;
import com.bqs.main.config.kafka.KafkaPatientWriter;
import com.bqs.main.model.FileProcessingLog;
import com.bqs.main.model.Patient;
import com.bqs.main.model.PatientChunk;
import com.bqs.main.model.PatientWrapper;
import com.bqs.main.utility.AESEncryptionUtil;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.support.SynchronizedItemStreamReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import java.time.LocalDateTime;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final S3BatchReader s3BatchReader;
    private final S3JobExecutionListener s3JobExecutionListener;

    @Autowired
    private AESEncryptionUtil aesEncryptionUtil;

    @Autowired
    public BatchConfig(JobRepository jobRepository,
                       PlatformTransactionManager transactionManager,
                       S3BatchReader s3BatchReader,
                       S3JobExecutionListener s3JobExecutionListener,
                       KafkaPatientWriter kafkaPatientWriter) {
        this.jobRepository = jobRepository;
        this.transactionManager = transactionManager;
        this.s3BatchReader = s3BatchReader;
        this.s3JobExecutionListener = s3JobExecutionListener;
    }

    @Bean
    @StepScope
    public KafkaPatientWriter kafkaPatientWriter(KafkaTemplate<String, PatientChunk> kafkaTemplate,
                                                 RetryTemplate retryTemplate) {
        return new KafkaPatientWriter(kafkaTemplate, retryTemplate);
    }

    @Bean
    @StepScope
    public SynchronizedItemStreamReader<Patient> synchronizedReader(@Value("#{jobParameters['fileKey']}") String fileKey) {
        SynchronizedItemStreamReader<Patient> syncReader = new SynchronizedItemStreamReader<>();
        syncReader.setDelegate(s3BatchReader.s3FlatFileItemReader(fileKey));
        return syncReader;
    }

    @Bean
    public Step patientStep(SynchronizedItemStreamReader<Patient> synchronizedReader,
                            KafkaPatientWriter kafkaPatientWriter, FileProcessingLog fileProcessingLog)  {

        final int[] dynamicChunkSize = {5000};

        // Create processor here
        ItemProcessor<Patient, PatientWrapper> patientProcessor = new PatientItemProcessor(fileProcessingLog, aesEncryptionUtil);

        return new StepBuilder("patientStep", jobRepository)
                .<Patient, PatientWrapper>chunk(dynamicChunkSize[0], transactionManager)
                .reader(synchronizedReader)
                .processor(patientProcessor)
                .writer(kafkaPatientWriter)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(Integer.MAX_VALUE)
                .taskExecutor(taskExecutor())
                .listener(new StepExecutionListener() {

                    @Override
                    public void beforeStep(StepExecution stepExecution) {
                        String fileKey = stepExecution.getJobParameters().getString("fileKey", "UNKNOWN");
                        Long chunkSizeParam = stepExecution.getJobParameters().getLong("chunkSize", 5000L);
                        dynamicChunkSize[0] = chunkSizeParam.intValue();

                        System.out.println("===>> Before Step: fileKey = " + fileKey);
                        System.out.println("===>> Before Step: Dynamic Chunk Size = " + dynamicChunkSize[0]);

                        // Read from ExecutionContext:
                        String fileSize = (String) stepExecution.getJobExecution().getExecutionContext().get("fileSize");
                        String fileType = (String) stepExecution.getJobExecution().getExecutionContext().get("fileType");
                        String fileName = (String) stepExecution.getJobExecution().getExecutionContext().get("fileName");

                        // Set into FileProcessingLog:
                        fileProcessingLog.setFileSize(fileSize);
                        fileProcessingLog.setFileType(fileType);
                        fileProcessingLog.setFileName(fileName);
                        fileProcessingLog.setProcessStartTime(LocalDateTime.now());
                    }

                    @Override
                    public ExitStatus afterStep(StepExecution stepExecution) {
                        fileProcessingLog.setProcessEndTime(LocalDateTime.now());
                        fileProcessingLog.setUpdatedDate(LocalDateTime.now());

                        // FINAL flush to Kafka!
                        System.out.println("==> Forcing final flush after step...");
                        kafkaPatientWriter.setFileProcessingLog(fileProcessingLog);
                        kafkaPatientWriter.flushBuffer();

                        return ExitStatus.COMPLETED;
                    }
                })
                .build();
    }

    @Bean
    public Job patientJob(Step patientStep) {
        return new JobBuilder("patientJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(patientStep)
                .listener(s3JobExecutionListener)
                .build();
    }

    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(50);
        executor.setQueueCapacity(10000);
        executor.setThreadNamePrefix("batch-thread-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.initialize();
        return executor;
    }

    @Bean
    @StepScope
    public FileProcessingLog fileProcessingLog() {
        FileProcessingLog log = new FileProcessingLog();
        log.setFileType("TXT");
        log.setFileSize("Unknown");
        log.setProcessStartTime(LocalDateTime.now());
        log.setCreatedDate(LocalDateTime.now());
        log.setUpdatedDate(LocalDateTime.now());
        return log;
    }
}
