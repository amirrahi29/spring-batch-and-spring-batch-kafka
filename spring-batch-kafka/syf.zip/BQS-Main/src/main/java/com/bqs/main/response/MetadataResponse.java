package com.bqs.main.response;

public class MetadataResponse {

    private String code;
    private String message;
    private String noOfRecords;
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getNoOfRecords() {
        return noOfRecords;
    }
    public void setNoOfRecords(String noOfRecords) {
        this.noOfRecords = noOfRecords;
    }

}
