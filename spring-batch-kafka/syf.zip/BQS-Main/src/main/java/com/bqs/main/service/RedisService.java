package com.bqs.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class RedisService {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Value("${app.redis.enabled:false}")
    private boolean redisEnabled;

    private static final String KEY_PREFIX = "processed_file:";

    public boolean isProcessed(String fileKey) {
        if (!redisEnabled) return false;
        return Boolean.TRUE.equals(redisTemplate.hasKey(KEY_PREFIX + fileKey));
    }

    public void markAsProcessed(String fileKey) {
        if (!redisEnabled) return;
        redisTemplate.opsForValue().set(KEY_PREFIX + fileKey, "DONE");
    }
}