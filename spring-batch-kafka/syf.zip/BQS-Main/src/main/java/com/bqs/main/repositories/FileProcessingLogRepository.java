package com.bqs.main.repositories;

import com.bqs.main.model.FileProcessingLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FileProcessingLogRepository extends JpaRepository<FileProcessingLog, Long> {}
